﻿Public Class About
    Inherits Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load



    End Sub

    Protected Sub chkSuite_CheckedChanged(sender As Object, e As EventArgs) Handles chkSuite.CheckedChanged

    End Sub

    Protected Sub txtName_TextChanged(sender As Object, e As EventArgs) Handles txtName.TextChanged

    End Sub

    Protected Sub chkPent_CheckedChanged(sender As Object, e As EventArgs) Handles chkPent.CheckedChanged

    End Sub

    Protected Sub cldArrival_SelectionChanged(sender As Object, e As EventArgs) Handles cldArrival.SelectionChanged

    End Sub

    Protected Sub ddlNights_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddlNights.SelectedIndexChanged

    End Sub

    Protected Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        Dim decHotelCost As Decimal
        Dim decSuiteCost As Decimal = 79D
        Dim decDeluxeCost As Decimal = 99D
        Dim decPenthouseCost As Decimal = 129D
        Dim intNumberOfNights As Integer = ddlNights.SelectedItem.Value
        If chkSuite.Checked Then
            decHotelCost += decSuiteCost * intNumberOfNights
        End If
        If chkDeluxe.Checked Then
            decHotelCost += decDeluxeCost * intNumberOfNights
        End If
        If chkPent.Checked Then
            decHotelCost += decPenthouseCost * intNumberOfNights
        End If

        If Not (chkSuite.Checked Or chkDeluxe.Checked Or chkDeluxe.Checked) Then
            lblHotelError.Visible = True
            If cldArrival.SelectedDate < cldArrival.TodaysDate Then
                lblCalenderError.Visible = True
            Else
                lblCalenderError.Visible = False
            End If
        End If



        Dim strMessage As String
        Dim strName As String = txtName.Text
        Dim strEmail As String = txtEmail.Text
        strMessage = "A reservation has been made for: " & "<br>" _
            & strName & "<br>" & "Email: " & strEmail & "<br>"
        strMessage &= "The Hotel(s) cost is: " _
            & decHotelCost.ToString("C") & "<br>"
        strMessage &= "Arrival Date: " _
            & cldArrival.SelectedDate.ToShortDateString() _
            & "<br>" & " for " & intNumberOfNights & " night(s)"
        lblReservation.Text = strMessage
    End Sub
End Class