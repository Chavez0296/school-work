﻿Public Class frmFitness
    Private Sub frmFitness_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub TextBox7_TextChanged(sender As Object, e As EventArgs) Handles TextBox7.TextChanged

    End Sub

    Private Sub TextBox6_TextChanged(sender As Object, e As EventArgs) Handles TextBox6.TextChanged

    End Sub

    Private Sub TextBox5_TextChanged(sender As Object, e As EventArgs) Handles TextBox5.TextChanged

    End Sub

    Private Sub TextBox4_TextChanged(sender As Object, e As EventArgs) Handles TextBox4.TextChanged

    End Sub

    Private Sub TextBox3_TextChanged(sender As Object, e As EventArgs) Handles TextBox3.TextChanged

    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBox2.TextChanged

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim d1, d2, m1, m2, y1, y2 As Integer
        d1 = Val(TextBox3.Text)
        d2 = Val(TextBox6.Text)
        m1 = Val(TextBox2.Text)
        m2 = Val(TextBox5.Text)
        y1 = Val(TextBox4.Text)
        y2 = Val(TextBox7.Text)

        Dim y, m, d As Integer
        Dim h As Double

        If y2 > y1 Then
            If m2 = m1 Then
                If d2 > d1 Then
                    d = d2 - d1
                    h = 2.5 * (d / 7)
                ElseIf d2 < d1 Then
                    lblResult.Text = "Invalid Dates"
                Else
                    d = 0
                    h = 0
                End If
            ElseIf m2 > m1 Then
                m = m2 - m1
                If d2 > d1 Then
                    d = d2 - d1
                    h = 2.5 * ((m * 30 + d) / 7)
                ElseIf d2 < d1 Then
                    d = 30 - (d1 - d2)
                    m = m - 1
                    h = 2.5 * ((m * 30 + d) / 7)
                Else
                    d = 0
                    h = 2.5 * ((m * 30 + d) / 7)
                End If
            ElseIf y2 > y1 Then
                y = y2 - y1
                If m2 = m1 Then
                    If d2 > d1 Then
                        d = d2 - d1
                        h = 2.5 * ((d + y * 365) / 7)
                    ElseIf d2 < d1 Then
                        d = 30 - (d1 - d2)
                        y = y - 1
                        m = 11
                        h = 2.5 * ((d + y * 365) / 7)

                    Else
                        d = 0
                        h = 2.5 * ((d + y * 365) / 7)
                    End If
                ElseIf m2 > m1 Then
                    m = m2 - m1
                    If d2 > d1 Then
                        d = d2 - d1
                        h = 2.5 * ((d + (y * 365) + (m * 30)) / 7)
                    ElseIf d2 < d1 Then
                        d = 30 - (d1 - d2)
                        m = m - 1
                        h = 2.5 * ((d + (y * 365) + (m * 30)) / 7)
                    Else
                        d = 0
                        h = 2.5 * ((d + (y * 365) + (m * 30)) / 7)
                    End If
                Else
                    m = 12 - (m1 - m2)

                    y = y - 1
                    If d2 > d1 Then
                        d = d2 - d1
                        h = 2.5 * ((d + (y * 365) + (m * 30)) / 7)

                    ElseIf d2 < d1 Then
                        d = 30 - (d1 - d2)
                        m = m - 1
                        h = 2.5 * ((d + (y * 365) + (m * 30)) / 7)
                    End If
                End If
            Else
                lblResult.Text = "Invalid Dates"
            End If
        End If
        lblResult.Text = TextBox1.Text + " has exercised " + h.ToString("0.00") + " hours."
    End Sub

    Private Sub lblResult_Click(sender As Object, e As EventArgs) Handles lblResult.Click

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        TextBox1.Clear()
        TextBox2.Clear()
        TextBox3.Clear()
        TextBox4.Clear()
        TextBox5.Clear()
        TextBox6.Clear()
        TextBox7.Clear()
        lblResult.Text = ""
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Close()
    End Sub
End Class
