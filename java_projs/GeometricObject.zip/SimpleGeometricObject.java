import java.util.Date;
// Chapter 11
public class SimpleGeometricObject {
  private String color = "white";
  private boolean filled;
  private Date dateCreated;

  /**Default construct*/
  protected SimpleGeometricObject() {
  }

  /**Construct a geometric object*/
  protected SimpleGeometricObject(String color, boolean filled) {
    this.color = color;
    this.filled = filled;
    this.dateCreated = new Date();
  }

  /**Getter method for color*/
  public String getColor() {
    return color;
  }

  /**Setter method for color*/
  public void setColor(String color) {
    this.color = color;
  }

  /**Getter method for filled. Since filled is boolean,
     so, the get method name is isFilled*/
  public boolean isFilled() {
    return filled;
  }

  /**Setter method for filled*/
  public void setFilled(boolean filled) {
    this.filled = filled;
  }

  public Date getDateCreated() {
    return dateCreated;
  }

  public String toString() {
     return "Created on " + dateCreated + "\nColor: " + color + "\nFilled: " + filled + "\n";
  }
}