class Main {
  public static void main(String[] args) {
    SimpleGeometricObject obj1 = new SimpleGeometricObject();
   System.out.println(obj1.toString());    
    SimpleGeometricObject obj2 = new SimpleGeometricObject("Red", true);
   System.out.println(obj2.toString());    

    CircleSimpleGeometricObject c1 = new CircleSimpleGeometricObject();
   System.out.println(c1.toString());    
    CircleSimpleGeometricObject c2 = new CircleSimpleGeometricObject(10);
   System.out.println(c2.toString());    
    CircleSimpleGeometricObject c3 = new CircleSimpleGeometricObject(5, "pink", false);
   System.out.println(c3.toString());  

    RectangleSimpleGeometricObject r1 = new RectangleSimpleGeometricObject();
   System.out.println(r1.toString());  
    RectangleSimpleGeometricObject r2 = new RectangleSimpleGeometricObject(10,5);
   System.out.println(r2.toString());  
    RectangleSimpleGeometricObject r3 = new RectangleSimpleGeometricObject(3, 5.6, "blue", true);
   System.out.println(r3.toString());  


    System.out.println(r3.getArea());
    System.out.println(c3.getArea());
    
  }
}